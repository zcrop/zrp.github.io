---
title: "The 14th International Conference on Digital Image Processing (ICDIP 2022)技术委员会委员"
excerpt: "The 14th International Conference on Digital Image Processing (ICDIP 2022), which has been held online during May 20-23, 2022.<br/>"
collection: services
# venue: "ICDIP"
# date: 2022-05-20
# location: "Haikou, China"
---
* The 14th International Conference on Digital Image Processing (ICDIP 2022), which has been held online during May 20-23, 2022.
* 第十四届数字图像处理国际会议技术委员会委员