---
title: "The 2022 Information Technology & Applications Symposium (ITAS)技术程序委员会主席"
excerpt: "2022 Information Technology & Applications Symposium (ITAS), to be held in Chiba, Japan, during June 24-26, 2022.<br/>"
collection: services
# venue: "ICCDE"
# date: 2022-06-24
# location: "Haikou, China"
---
* The 2022 Information Technology & Applications Symposium (ITAS), to be held in Chiba, Japan, during June 24-26, 2022.
* 2022信息技术与应用学术研讨会技术程序委员会主席
<br>
* 会议网址：<a href="http://itas.org/index.html"> [ITAS]</a>
<br>

* 截图证明
<img src='/images/ICCDE.jpg'>
