---
title: "The 6th & 7th International Conference on Machine Learning and Soft Computing程序委员会主席"
excerpt: "ICMLSC 2022和ICMLSC 2023, The 6th & 7th International Conference on Machine Learning and Soft Computing, will take place in Haikou, China, from January 15-17, 2022. <br/>
"
collection: services

# venue: "ICMLSC"
# date: 2022-01-15
# location: "Haikou, China"
---

* ICMLSC 2022和ICMLSC 2023, The 6th & 7th International Conference on Machine Learning and Soft Computing, will take place in Haikou, China, from January 15-17, 2022. 
* 第六届和第七届机器学习与软计算国际会议程序委员会主席
* 会议网址: <a href= "http://icmlsc.org/com.html">[ICMLSC]