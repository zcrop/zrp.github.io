---
title: "The 2023 9th International Conference on Computing and Data Engineering (ICCDE 2023)国际计算机与数据工程大会主席"
excerpt: "The 2023 9th International Conference on Computing and Data Engineering (ICCDE 2023),Haikou, China during January 6-8, 2023.<br/><img src='/images/services/ICCDE.jpg'>"
collection: services
# venue: "ICCDE"
# date: 2023-01-06
# location: "Haikou, China"
---
* The 2023 9th International Conference on Computing and Data Engineering (ICCDE 2023),Haikou, China during January 6-8, 2023.
* 2023年第九届计算与数据工程国际会议主席
* 会议网址: <a href= "http://iccde.org/index.html">[ICCDE 2023]
</a>
<br>
<img src='/images/services/ICCDE.jpg'>