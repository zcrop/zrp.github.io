---
title: "合作伙伴"
permalink: /friends/
layout: posts
entries_layout: grid
author_profile: true
---
<!--     主题中的 _layouts/posts.html 布局文件定义了文章列表的显示方式。它会遍历 _posts 目录下的所有文章，并按照日期进行排序和分组。
    在 _layouts/posts.html 中，通过使用 Liquid 模板语言和相关的 Jekyll 过滤器，提取每篇文章的日期信息。
    根据提取的日期信息，生成年份归档页面的链接和标题。
    当你访问 /year-archive/ 页面时，Jekyll 会根据配置的 permalink，将请求映射到 year-archive.md 页面，并加载对应的布局模板 _layouts/posts.html。
    _layouts/posts.html 在生成页面时，根据提取的日期信息，筛选出属于特定年份的文章，并按照日期倒序排列。
    最终，生成的年份归档页面会展示属于该年份的文章列表。 -->