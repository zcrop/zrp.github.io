---
permalink: /accomplishments/
title: "获奖和荣誉"
classes: wide
# author_profile: false
excerpt: "获奖和荣誉"
toc: true  # 生成目录
toc_icon: "cog" 
# tags: 
#   - sample post
#   - readability
#   - test
---
<!-- <a href="#top" class="up-to-top">Back to Top</a> -->

<!-- * 目录
{:toc} -->
<br>
<!-- ## 所获奖项 -->
1. 海南省科技进步一等奖，“近海环境监控多源信息协同感知与融合关键技术及其应用”， 海南省人民政府, 2021.11；
2. 海南省计算机学会“先进会员”奖，2020.11.29；
3. 海南省高等学校“人工智能领域”科学研究优秀指导教师奖，2019.12.29；
4. 获2018年海南大学“优秀教师”称号；
5. <a href="http://xxgk.hainan.gov.cn/hi/HI0108/201610/t20161020_2144933.htm">2016年海南省第二届“互联网+”创新创业大赛优秀指导教师；</a>
6. 彭金莲，陈显毅，胡祝华，郑兆华，钟杰卓. 海南省教学成果奖一等奖（第三）,网络工程专业应用型工程人才培养体系的研究与实践,2014.12。