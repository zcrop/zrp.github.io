---
layout: archive
title: "News （课题组最近的消息）"
permalink: /news/
author_profile: true
type: posts
---
<!-- 
{% if author.googlescholar %}
  You can also find my articles on <u><a href="{{author.googlescholar}}">my Google Scholar profile</a>.</u>
{% endif %}

{% include base_path %}


{% for post in site.research reversed %}  
  {% include archive-single-cv.html %}
{% endfor %}
 -->

<ul>
<p style="margin-top: 6px;"><li>[<font color="red">May, 2023</font>] "<b> TFF_aDCNN: A Pre-trained Base Model for Intelligent Wideband Spectrum Sensing</b>" has been submitted to <font color="green">IEEE Transactions on Vehicular Technology</font> <font color="blue">(Status: Accepted)</font>.</li></p>

<p style="margin-top: 6px;"><li>[<font color="red">January, 2023</font>] "<b>An Intelligent Measurement Scheme for Basic Characters of Fish in Smart Aquaculture</b>" has been submitted to <font color="green">Computers and Electronics in Agriculture</font> <font color="blue">(Status: Accepted)</font>.</li></p>
  
<p style="margin-top: 6px;"><li>[<font color="red">October, 2022</font>] "<b>DualA_SL: Salient Object Detection Driven by Dual Attention and Structured Loss</b>" has been submitted to <font color="green">Image and Vision Computing (IMAVIS)</font> <font color="blue">(Status: Under Review)</font>.</li></p>
  
<p style="margin-top: 6px;"><li>[<font color="red">September, 2022</font>] "<b>KPCRN: Key-Point-Coordinate Regression Network for Fish Characteristics Measurement</b>" has been submitted to <font color="green">IEEE Transactions on Instrumnetation & Measurement (TIM)</font> <font color="blue">(Status: Under Review)</font>.</li></p>
  
<p style="margin-top: 6px;"><li>[<font color="red">September, 2022</font>] "<b>An Intelligent Measurement Scheme for Basic Characters of Fish in Smart Aquaculture</b>" has been submitted to <font color="green">Computers and Electronics in Agriculture (CEA)</font> <font color="blue">(Status: Accepted)</font>.</li></p>

</ul> 