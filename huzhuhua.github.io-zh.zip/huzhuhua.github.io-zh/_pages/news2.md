---
layout: archive
title: "News （课题组最近的消息）"
permalink: /news0/
author_profile: true
type: posts
---


<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Limin Wang</title>
	<meta content="Limin Wang, wanglimin.github.io" name="keywords" />
	<style media="screen" type="text/css">html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, font, img, ins, kbd, q, s, samp, small, strike, strong, sub, tt, var, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td {
  border: 0pt none;
  font-family: inherit;
  font-size: 100%;
  font-style: inherit;
  font-weight: inherit;
  margin: 0pt;
  outline-color: invert;
  outline-style: none;
  outline-width: 0pt;
  padding: 0pt;
  vertical-align: baseline;
}

a {
  color: #1772d0;
  text-decoration:none;
}

a:focus, a:hover {
  color: #f09228;
  text-decoration:none;
}

a.paper {
  font-weight: bold;
  font-size: 12pt;
}

b.paper {
  font-weight: bold;
  font-size: 12pt;
}

* {
  margin: 0pt;
  padding: 0pt;
}

body {
  position: relative;
  margin: 3em auto 2em auto;
  width: 800px;
  font-family: Lato, Verdana, Helvetica, sans-serif;
  font-size: 14px;
  background: #eee;
}

h2 {
  font-family: Lato, Verdana, Helvetica, sans-serif;
  font-size: 15pt;
  font-weight: 700;
}

h3 {
  font-family: Lato, Verdana, Helvetica, sans-serif;
  font-size: 16px;
  font-weight: 700;
}

strong {
  font-family: Lato, Verdana, Helvetica, sans-serif;
  font-size: 13px;
  font-weight:bold;
}

ul { 
  list-style: circle;
}

img {
  border: none;
}

li {
  padding-bottom: 0.5em;
  margin-left: 1.4em;
}

alert {
  font-family: Lato, Verdana, Helvetica, sans-serif;
  font-size: 13px;
  font-weight: bold;
  color: #FF0000;
}

em, i {
	font-style:italic;
}

div.section {
  clear: both;
  margin-bottom: 1.5em;
  background: #eee;
}

div.spanner {
  clear: both;
}

div.paper {
  clear: both;
  margin-top: 0.5em;
  margin-bottom: 1em;
  border: 1px solid #ddd;
  background: #fff;
  padding: 1em 1em 1em 1em;
}

div.paper div {
  padding-left: 230px;
}

img.paper {
  margin-bottom: 0.5em;
  float: left;
  width: 200px;
}

span.blurb {
  font-style:italic;
  display:block;
  margin-top:0.75em;
  margin-bottom:0.5em;
}

pre, code {
  font-family: 'Lucida Console', 'Andale Mono', 'Courier', monospaced;
  margin: 1em 0;
  padding: 0;
}

div.paper pre {
  font-size: 0.9em;
}
</style>

<link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" /><!--<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>--><!--<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>--><!--<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz' rel='stylesheet' type='text/css'>-->
</head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-45959174-3', 'wanglimin.github.io');
  ga('send', 'pageview');
</script>

<body>
<div style="margin-bottom: 1em; border: 1px solid #ddd; background-color: #fff; padding: 1em; height: 130px;">
<div style="margin: 0px auto; width: 100%;">
<img title="lmwang" style="float: left; padding-left: .01em; height: 130px;" src="wlm.JPG" />
<div style="padding-left: 10em; vertical-align: top; height: 120px;"><span style="line-height: 150%; font-size: 15pt;">Limin Wang (王利民)</span><br />
<span><a href='http://mcg.nju.edu.cn/en/index.html'>Multimedia Computing Group</a></span> <br />
<span><a href='http://cs.nju.edu.cn'>Department of Computer Science and Technology</a></span> <br />
<span><a href='http://www.nju.edu.cn'>Nanjing University</a></span><br />
<span><strong>Office</strong>: CS Building 506 </span><br />
<span><strong>Email</strong>: lmwang.nju [at] gmail.com</span> <br /> 
</div>
</div>
</div>
<!--<div style="clear: both; background-color: #fff; margin-top: 1.5em; padding: .2em; padding-left: .3em;">-->

<div style="clear: both;">
<div class="section">
<h2>About Me (<a href='wlm_cv.pdf'>CV</a>)</h2>
<div class="paper">
I am a Professor at <a href='http://cs.nju.edu.cn'>Department of Computer Science and Technology</a> and also affiliated with <a href='https://keysoftlab.nju.edu.cn/'>State Key Laboratory for Novel Software Technology</a>, Nanjing University.
<br>
<br>
Previously, I received the B.S. degree from <a href='http://www.nju.edu.cn/'>Nanjing University</a> in 2011, and the Ph.D. degree from <a href='http://www.cuhk.edu.hk/chinese/index.html'>The Chinese University of Hong Kong</a> under the supervision of Prof. <a href='http://www.ie.cuhk.edu.hk/people/xotang.shtml'>Xiaoou Tang</a> in 2015. From 2015 to 2018, I was a Post-Doctoral Researcher with Prof. <a href="http://www.vision.ee.ethz.ch/members/get_member.cgi?lang=en&id=1">Luc Van Gool</a> in the <a href='http://www.vision.ee.ethz.ch/en/'>Computer Vision Laboratory</a> (CVL) at <a href="https://www.ethz.ch/en.html">ETH Zurich</a>. 
</div>
</div>
</div>

<div style="clear: both;">
<div class="section">
  <h2>News</h2>
  <div class="paper">
    <ul>
      <li> 2022-03-02: Seven papers on object detection, object tracking, action recognition etc. are accepted by CVPR 2022.</li>
    <li> 2021-07-25: Five papers on video understanding are accepted by ICCV 2021: new dataset (<a href='https://arxiv.org/abs/2105.07404'>MultiSports</a>), backbone (<a href='https://arxiv.org/abs/2005.06803'>TAM</a>), sampling method (<a href='https://arxiv.org/abs/2104.09952'>MGSampler</a>), detection frameworks (<a href='https://arxiv.org/abs/2102.01894'>RTD</a> and <a href='https://arxiv.org/abs/2108.08121'>TRACE</a>). For more details, please refer to our papers. 
    <li> 2021-07-15: <alert>  We release the <a href='https://deeperaction.github.io/multisports/'>MultiSports dataset</a> for spatiotemporal action detection. <alert>  </li> 
    <li> 2021-07-15: Our team secures the first place at <a href='http://auto-video-captions.top/2021/'>ACM MM Pre-training for Video Understanding Challenge</a> for Track 2. </li> 
    <li> 2021-06-15: Our team secures the first place at <a href='https://eval.ai/web/challenges/challenge-page/1054/overview'>CVPR Kinetics Challenge</a> for Self-Supervised Task. </li>
    <li> 2021-06-15: Our team secures the first place at <a href='http://www.picdataset.com/challenge/task/hcvg/'>CVPR PIC Challenge</a> for Human-Centric Spatio-Temporal Video Grounding Task. </li>
    <li> 2021-06-01: <alert> We are organizing <a href='https://deeperaction.github.io'>DeeperAction Challenge</a> at ICCV 2021, by introducing three new benchmarks on temporal action localization, spatiotemporal action detection, and part-level action parsing.  </alert> </li>
    <li> 2021-04-20: The extension of TRecgNet is accpeted by IJCV. </li>
    <li> 2021-04-07: We propose a target transformer for accurate anchor-free tracking, termed as <a href='https://arxiv.org/abs/2104.00403'>TREG</a> (code comming soon). </li>
    <li> 2021-04-07: We present a transformer decoder for direct action proposal generation, termed as <a href='https://arxiv.org/abs/2102.01894'>RTD-Net</a> (code comming soon). </li>	
    <li> 2021-03-01: Two papers on action recognition and point cloud segmentation are accepted by CVPR 2021. </li>	
    <li> 2020-12-30: We propose a new video architecture of using temporal difference, termed as <a href='https://arxiv.org/abs/2012.10071'>TDN</a> and realease the <a href='https://github.com/MCG-NJU/TDN'>code</a>. </li>	
    <li> 2020-07-03: Three papers on action detection and segmentation are accepted by ECCV 2020. </li>	
    <li> 2020-06-28: Our proposed <a href='https://arxiv.org/abs/2006.15560'>DSN</a>, a dynamic version of TSN for efficient action recognition, is accepted by TIP. </li>	
    <li> 2020-05-14: We propose a temporal adaptive module for video recognition, termed as <a href='https://arxiv.org/abs/2005.06803'>TAM</a> and <a href='https://github.com/liu-zhy/TANet'>code</a>. </li>
    <li> 2020-04-16: The code of our published papers will be made available at <a href='https://github.com/MCG-NJU'>Github: MCG-NJU</a>. </li>  
    <li> 2020-04-16: We propose a fully convolutional online tracking framwork, termed as <a href='https://arxiv.org/abs/2004.07109'>FCOT</a> and <a href='https://github.com/MCG-NJU/FCOT'>code</a>. </li>
    <li> 2020-03-10: Our proposed temporal module <a href='https://arxiv.org/abs/2004.01398'>TEA</a> is accepted by CVPR 2020. </li>
    <li> 2020-01-20: We propose an efficient video representation learning framwork, termed as <a href='https://arxiv.org/abs/2001.05691'>CPD</a> and release the <a href='https://github.com/MCG-NJU/CPD-Video'>code</a>. </li>
    <li> 2020-01-15: We present an anchor-free action tubelet detector, termed as <a href='https://arxiv.org/abs/2001.04608'>MOC-Detector</a> and release the <a href='https://github.com/MCG-NJU/MOC-Detector'>code</a>. </li>
    <li> 2019-12-20: Our proposed <a href='https://arxiv.org/abs/2002.07442'> V4D</a>, a principled video-level represenation learning framework, is accepted by ICLR 2020. </li>
    <li> 2019-11-21: Our proposed <a href='https://arxiv.org/abs/1911.09435'>TEINet</a>, an efficient video archiecture for video recognition, is accepted by AAAI 2020. </li>
    <li> 2019-07-23: Our proposed <a href='https://arxiv.org/abs/1908.04156'>LIP</a>, a general alternative to average or max pooling, is accepted by ICCV 2019. </li>
    <li> 2019-03-15: Two papers are accepted by CVPR 2019: one for group activity recognition and one for RGB-D transfer learning. </li>
    <li> 2018-08-19: One paper is accepted by ECCV 2018 and one by T-PAMI. </li>
    <li> 2018-04-01: <alert>I join <a href='https://www.nju.edu.cn/'>Nanjing University</a> as a faculty member at <a href='http://cs.nju.edu.cn/'>Department of Computer Science and Technology</a></alert>. </li>
    <li> 2017-11-28: We released a recent work on video architecture design for spatiotemporal feature learning. [ <a href='https://arxiv.org/abs/1711.09125'>arXiv</a> ] [ <a href='https://github.com/wanglimin/ARTNet'>Code</a> ].  </li>
    <li> 2017-09-08: We have released the TSN models learned in the <a href='http://yjxiong.me/others/kinetics_action/'>Kinetics</a> dataset. These models could be transferred well to the existing datasets for action recognition and detection [ <a href='http://yjxiong.me/others/kinetics_action/'>Link</a> ].  </li>
    <li> 2017-09-01: One paper is accepted by ICCV 2017 and one by IJCV. </li>
    <li> 2017-07-18: I am invited to give a talk at the <a href='https://sites.google.com/view/fvt2017/home'>Workshop on Frontiers of Video Technology-2017</a> [ <a href='fvt_slide.pdf'>Slide</a> ].
    <li> 2017-03-28: <alert>I am co-organizing the CVPR2017 workshop and challenge on Visual Understanding by Learning from Web Data</alert>. For more details, please see the <a href='http://www.vision.ee.ethz.ch/webvision/workshop.html'>workshop page</a> and <a href='https://competitions.codalab.org/competitions/16439'>challenge page</a>. </li>
    <li> 2017-02-28: Two papers are accepted by CVPR 2017. </li>
    <li> 2016-12-20: <alert>We release the code and models for SR-CNN paper</alert> [ <a href='https://github.com/yifita/action.sr_cnn'>Code</a> ]. </li> 
    <li> 2016-10-05: <alert>We release the code and models for Places2 scene recognition challenge</alert> [ <a href='https://arxiv.org/abs/1610.01119'>arXiv</a> ] [ <a href='https://github.com/wanglimin/MRCNN-Scene-Recognition'>Code</a> ]. </li>
    <li> 2016-08-03: <alert>Code and model of Temporal Segment Networks is released</alert> [ <a href='http://arxiv.org/abs/1608.00859'>arXiv</a> ] [ <a href='https://github.com/yjxiong/temporal-segment-networks'>Code</a> ]. </li>
    <li> 2016-07-15: One paper is accepted by ECCV 2016 and one by BMVC 2016. </li>
    <li> 2016-06-16: <alert>Our team secures the 1st place for untrimmed video classification at ActivityNet Challenge 2016</alert> [ <a href='http://activity-net.org/challenges/2016/program.html'>Result</a> ]. <br>
    Basically, our solution is based on our works of <a href='https://github.com/yjxiong/temporal-segment-networks'>Temporal Segment Networks</a> (TSN) and <a href = 'https://github.com/wanglimin/TDD'>Trajectory-pooled Deep-convolutional Descriptors</a> (TDD). </li>
    <li> 2016-03-01: Two papers are accepted by CVPR 2016. </li>
      <li> 2015-12-10: <alert>Our SIAT_MMLAB team secures the 2nd place for scene recognition at ILSVRC 2015 </alert> [ <a href='http://image-net.org/challenges/LSVRC/2015/results#scene'>Result</a> ].</li>
    <li> 2015-09-30: We rank 3rd for cultural event recognition on ChaLearn Looking at People challenge, at ICCV 2015. </li>
      <li> 2015-08-07: <alert>We release the Places205-VGGNet models</alert> [ <a href='https://github.com/wanglimin/Places205-VGGNet'>Link</a> ]. </li>
    <li> 2015-07-22: <alert>Code of Trajectory-Pooled Deep-onvolutional Descriptors (TDD) is released</alert> [ <a href='https://github.com/wanglimin/TDD'>Link</a> ]. </li>
		<li> 2015-07-15: <alert>Very deep two stream ConvNets are proposed for action recognition</alert> [ <a href='http://arxiv.org/abs/1507.02159'>Link</a> ]. </li>
	        <li> 2015-03-15: We are the 1st winner of both tracks for action recognition and cultural event recognition, on ChaLearn <a href='http://gesture.chalearn.org/'>Looking at People Challenge</a> at CVPR 2015. </li>
		<!-- <li> March 3, 2015: One paper is accepted by CVPR 2015, details coming soon. </li>
	        <li> Sep 5, 2014: We rank 4th for action recognition and 2nd for action detection, on <a href='http://crcv.ucf.edu/THUMOS14/home.html'>THUMOS'14 Challenge</a> at ECCV 2014. </li>
		<li> June 16, 2014: Two papers are accepted by ECCV 2014. </li>
		<li> June 10, 2014: We are the 1st winner of both track 1 and track2, and rank 4th for track3, on ChaLearn <a href='http://gesture.chalearn.org/'>Looking at People Challenge</a> at ECCV 2014. </li>
		<li> May 20, 2014: A comprehensive study paper on action recognition [ <a href='http://arxiv.org/abs/1405.4506'>Link</a> ]. </li>
		<li> May 16, 2014: New homepage on github launched! </li> -->
    </ul>
  </div>
</div>
</div>

<div style="clear: both;">
<div class="section">
<h2 id="confpapers">Selected Publications [ <a href='publication.html'>Full List</a> ] [ <a href='https://scholar.google.com.hk/citations?user=HEuN8PcAAAAJ&hl=en'>Google Scholar</a> ] [ <a href='https://github.com/MCG-NJU'>Github: MCG-NJU</a> ] </h2>



<div class="paper" id="TREG"><img class="paper" src="papers/treg_21.png" title="Target Transformed Regression for Accurate Tracking" />
<div> <strong>Target Transformed Regression for Accurate Tracking</strong><br />
Y. Cui, C. Jiang, L. Wang, G. Wu<br />
Technical Report, 2021. <br />
[ <a href='https://arxiv.org/abs/2104.00403'>Paper</a> ] [ <a href=''>Code</a> ] <br />
<alert>Transformer for anchor-free tracking with obtaining SOTA performance</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="FCOT"><img class="paper" src="papers/FCOT_20.png" title="Fully Convolutional Online Tracking" />
<div> <strong>Fully Convolutional Online Tracking</strong><br />
Y. Cui, C. Jiang, L. Wang, G. Wu<br />
Technical Report, 2020. <br />
[ <a href='https://arxiv.org/abs/2004.07109'>Paper</a> ] [ <a href='https://github.com/MCG-NJU/FCOT'>Code</a> ] <br />
<alert>Online learning of both classification and regression branch in a fully convolutional manner.</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="CPD"><img class="paper" src="papers/CPD_20.png" title="Learning Spatiotemporal Features via Video and Text Pair Discrimination" />
<div> <strong>Learning Spatiotemporal Features via Video and Text Pair Discrimination</strong><br />
T. Li, L. Wang<br />
Technical Report, 2020. <br />
[ <a href='https://arxiv.org/abs/2001.05691'>Paper</a> ] [ <a href='https://github.com/MCG-NJU/CPD-Video'>Code</a> ] <br />
<alert>We propose a weakly supervised video representation learning framework from text information.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="PyMAF"><img class="paper" src="papers/pymaf_21.png" title="3D Human Pose and Shape Regression with Pyramidal Mesh Alignment Feedback Loop" />
<div> <strong>3D Human Pose and Shape Regression with Pyramidal Mesh Alignment Feedback Loop</strong><br />
H. Zhang, Y. Tian, X. Zhou, W. Ouyang, Y. Liu, L. Wang, Z. Sun<br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2021. <br />
[ <a href='https://arxiv.org/abs/2103.16507'>Paper</a> ] [ <a href='https://github.com/HongwenZhang/PyMAF'>Code</a> ] [ <a href='https://hongwenzhang.github.io/pymaf/'>Project Page</a> ]<br />
<alert></alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="MGSampler"><img class="paper" src="papers/mgsampler_21.png" title=">MGSampler: An Explainable Sampling Strategy for Video Action Recognition" />
<div> <strong>MGSampler: An Explainable Sampling Strategy for Video Action Recognition</strong><br />
  Y. Zhi, Z. Tong, L. Wang, G. Wu<br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2021. <br />
[ <a href='https://arxiv.org/abs/2104.09952'>Paper</a> ] [ <a href=''>Code (soon)</a> ] <br />
<alert>A simple, general, and explainable video sampling method.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="MultiSports"><img class="paper" src="papers/multisports_21.png" title="MultiSports: A Multi-Person Video Dataset of Spatio-Temporally Localized Sports Actions" />
<div> <strong>MultiSports: A Multi-Person Video Dataset of Spatio-Temporally Localized Sports Actions</strong><br />
Y. Li, L. Chen, R. He, Z. Wang, G. Wu, L. Wang<br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2021. <br />
[ <a href='https://arxiv.org/abs/2105.07404'>Paper</a> ] [ <a href='https://deeperaction.github.io/multisports/'>Data</a> ] [ <a href='https://github.com/MCG-NJU/MultiSports/'>Code</a> ] [ <a href='https://competitions.codalab.org/competitions/32066'>Challenge</a> ] <br />
<alert>A high-quality and fine-grained action detection benchmark.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="TAM"><img class="paper" src="papers/TAM_20.png" title="TAM: Temporal Adaptive Module for Video Recognition" />
<div> <strong>TAM: Temporal Adaptive Module for Video Recognition</strong><br />
Z. Liu, L. Wang, W. Wu, C. Qian, T. Lu<br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2021. <br />
[ <a href='https://arxiv.org/abs/2005.06803'>Paper</a> ] [ <a href='https://github.com/liu-zhy/TANet'>Code</a> ] <br />
<alert>Temporal adaptive module of self attention + dynamic filtering for video recognition.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="RTD"><img class="paper" src="papers/rtd_21.png" title="Relaxed Transformer Decoders for Direct Action Proposal Generation" />
<div> <strong>Relaxed Transformer Decoders for Direct Action Proposal Generation</strong><br />
J. Tan, J. Tang, L. Wang, G. Wu<br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2021. <br />
[ <a href='https://arxiv.org/abs/2102.01894'>Paper</a> ] [ <a href='https://github.com/MCG-NJU/RTD-Action'>Code</a> ] <br />
<alert>Transformer for direct action proposal generation</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="CMPT"><img class="paper" src="papers/cmpt_21.png" title="Cross-Modal Pyramid Translation for RGB-D Scene Recognition" />
<div> <strong>Cross-Modal Pyramid Translation for RGB-D Scene Recognition</strong><br />
in International Journal of Computer Vision (<strong>IJCV</strong>), in IJCV, 2021. <br />
[ <a href='https://link.springer.com/article/10.1007/s11263-021-01475-7'>Paper</a> ]  [ <a href='https://github.com/MCG-NJU/CMPT'>Code</a> ] <br />
<alert>Journal extension of TRecgNet with pyramid translation extension.</alert><br />
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="TDN"><img class="paper" src="papers/tdn_20.png" title="TDN: Temporal Difference Networks for Efficient Action Recognition" />
<div> <strong>TDN: Temporal Difference Networks for Efficient Action Recognition</strong><br />
L. Wang, Z. Tong, B. Ji, G. Wu<br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2021.  <br />
[ <a href='https://arxiv.org/abs/2012.10071'>Paper</a> ] [ <a href='https://github.com/MCG-NJU/TDN'>Code</a> ] <br />
<alert>Temporal modeling with an explicit difference operation.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="TEA"><img class="paper" src="papers/bcn_20.png" title="Boundary-Aware Cascade Networks for Temporal Action Segmentation" />
<div> <strong>Boundary-Aware Cascade Networks for Temporal Action Segmentation</strong><br />
Z. Wang, Z. Gao, L. Wang, Z. Li, and G. Wu<br />
in European Conference on Computer Vision (<strong>ECCV</strong>), 2020. <br />
[ <a href=''>Paper</a> ] [ <a href='https://github.com/MCG-NJU/BCN'>Code</a> ] <br />
<alert>SOTA performance for action segmentation on three benchmarks.</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="TEA"><img class="paper" src="papers/crcnn_20.png" title="Context-Aware RCNN: a Baseline for Action Detection in Videos" />
<div> <strong>Context-Aware RCNN: a Baseline for Action Detection in Videos</strong><br />
J. Wu, Z. Kuang, L. Wang, W. Zhang, G. Wu<br />
in European Conference on Computer Vision (<strong>ECCV</strong>), 2020.  <br />
[ <a href='https://arxiv.org/abs/2007.09861'>Paper</a> ] [ <a href='https://github.com/MCG-NJU/CRCNN-Action'>Code</a> ] <br />
<alert>A simple baseline for action detection in videos.</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="MOC-Dector"><img class="paper" src="papers/MOC_20.png" title="Actions as Moving Points" />
<div> <strong>Actions as Moving Points</strong><br />
Y. Li, Z. Wang, L. Wang, G. Wu <br />
in European Conference on Computer Vision (<strong>ECCV</strong>), 2020. <br />
[ <a href='https://arxiv.org/abs/2001.04608'>Paper</a> ] [ <a href='https://github.com/MCG-NJU/MOC-Detector'>Code</a> ] <br />
<alert>MOC-detector is an anchor-free action tubelet detector, obtaining SOTA on JHMDB and UCF.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="DSN"><img class="paper" src="papers/DSN_20.png" title="Dynamic Sampling Networks for Efficient Action Recognition in Videos" />
<div> <strong>Dynamic Sampling Networks for Efficient Action Recognition in Videos</strong><br />
Y. Zheng, Z. Liu, T. Lu, L. Wang<br />
in IEEE Transactions on Image Processing (<strong>TIP</strong>), 2020. <br />
[ <a href='https://arxiv.org/abs/2006.15560'>Paper</a> ] <br />
<alert>A dynamic version of TSN for efficient action recognition.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="V4D"><img class="paper" src="papers/V4D_20.PNG" title="" />
<div> <strong>V4D: 4D Convolutional Neural Networks for Video-Level Representation Learning</strong><br />
S. Zhang, S. Guo, W. Huang, M. Scott, L. Wang <br />
in International Conference on Learning Representations (<strong>ICLR</strong>), 2020. <br />
[ <a href='https://arxiv.org/abs/1705.02953'>Paper</a> ] [ <a href='https://github.com/MalongTech/research-v4d'>Code</a> ] <br />
<alert>V4D is an extension over TSN for video-level representation learning.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="TEA"><img class="paper" src="papers/TEA_20.png" title="TEA: Temporal Excitation and Aggregation for Action Recognition" />
<div> <strong>TEA: Temporal Excitation and Aggregation for Action Recognition</strong><br />
Y. Li, B. Ji, X. Shi, J. Zhang, B. Kang, L. Wang <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2020.  <br />
[ <a href='https://arxiv.org/abs/2004.01398'>Paper</a> ] [ <a href='https://github.com/Phoenix1327/tea-action-recognition'>Code</a> ] <br />
<alert>We propose a lightweight temporal module for video recognition.</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="Liu"><img class="paper" src="papers/TEI_20.png" title="TEINet: Towards an Efficient Architecture for Video Recognition" />
<div> <strong>TEINet: Towards an Efficient Architecture for Video Recognition</strong><br />
Z. Liu, D. Luo, Y. Wang, L. Wang, Y. Tai, C. Wang, J. Li, F. Huang, T. Lu <br />
in AAAI Conference on Artificial Intelligence (<strong>AAAI</strong>), 2020. <br />
[ <a href='https://arxiv.org/abs/1911.09435'>Paper</a> ] <br />
<alert>An efficient architecture for video recognition based on 2D CNN.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="GaoWW"><img class="paper" src="papers/GaoWW_19.png" title="LIP: Local Importance-based Pooling" />
<div> <strong>LIP: Local Importance-based Pooling</strong><br />
Z. Gao, L. Wang and G. Wu <br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2019. <br />
[ <a href='https://arxiv.org/abs/1908.04156'>Paper</a> ] [ <a href='https://github.com/sebgao/LIP'>Code</a> ] <br />
<alert>A general downsampling alternative to max or average pooling.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WuWWGW"><img class="paper" src="papers/WuWWGW_19.png" title="Learning Actor Relation Graphs for Group Activity Recognition" />
<div> <strong>Learning Actor Relation Graphs for Group Activity Recognition</strong><br />
J. Wang, L. Wang, L. Wang, J. Guo and G. Wu <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2019. <br />
[ <a href='https://arxiv.org/abs/1904.10117'>Paper</a> ] [ <a href='https://github.com/wjchaoGit/Group-Activity-Recognition'>Code</a> ] <br />
<alert>Obtaining STOA performance on datasets of Volleyball and Collective Activity.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="DuWWZW"><img class="paper" src="papers/DuWWZW_19.png" title="Translate-to-Recognize Networks for RGB-D Scene Recognition" />
<div> <strong>Translate-to-Recognize Networks for RGB-D Scene Recognition</strong><br />
D. Du, L. Wang, H. Wang, K. Zhao and G. Wu <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2019. <br />
[ <a href='https://arxiv.org/abs/1904.12254'>Paper</a> ] [ <a href='https://github.com/ownstyledu/Translate-to-Recognize-Networks'>Code</a> ] [ <a href='https://ownstyledu.github.io/Translate-to-Recognize-Networks/'>Project Page</a> ] <br />
<alert>A new cross-modal transfer framework for RGB-D scene recognition.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangLLV"><img class="paper" src="papers/WangLLV_18.png" title="Appearance-and-Relation Networks for Video Classification" />
<div> <strong>Appearance-and-Relation Networks for Video Classification</strong><br />
L. Wang, W. Li, W. Li, and L. Van Gool <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2018. <br />
[ <a href='https://arxiv.org/abs/1711.09125'>Paper</a> ] [ <a href='https://github.com/wanglimin/ARTNet'>Code</a> ] <br />
<alert>A new architecture for spatiotemporal feature learning.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangWQV_IJCV18"><img class="paper" src="papers/WangWQV_IJCV18.png" title="Transferring Deep Object and Scene Representations for Event Recognition in Still Images" />
<div> <strong>Transferring Deep Object and Scene Representations for Event Recognition in Still Images</strong><br />
L. Wang, Z. Wang, Y. Qiao, and L. Van Gool <br />
in International Journal of Computer Vision (<strong>IJCV</strong>), 2018. <br />
[ <a href='https://link.springer.com/article/10.1007/s11263-017-1043-5'>Paper</a> ] [ <a href='https://github.com/wangzheallen/transfer_ijcv'>Code</a> ] <br />
<alert>STOA performance for event recognition on ChaLearn LAP cultural event, WIDER datasets.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="Zhao_ICCV17"><img class="paper" src="papers/Zhao_ICCV17.png" title="Temporal Action Detection with Structured Segment Networks" />
<div> <strong>Temporal Action Detection with Structured Segment Networks</strong><br />
Y. Zhao, Y. Xiong, L. Wang, Z. Wu, X. Tang, and D. Lin<br />
in IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2017. <br />
[ <a href='https://arxiv.org/abs/1704.06228'>Paper</a> ] [ <a href='https://github.com/yjxiong/action-detection'>Code</a> ] <br />
<alert>A new framework for temporal action localization.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangXLV_CVPR17"><img class="paper" src="papers/WangXLV_CVPR17.png" title="UntrimmedNets for Weakly Supervised Action Recognition and Detection" />
<div> <strong>UntrimmedNets for Weakly Supervised Action Recognition and Detection</strong><br />
L. Wang, Y. Xiong, D. Lin, and L. Van Gool <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2017. <br />
[ <a href='https://arxiv.org/abs/1703.03329'>Paper</a> ] [ <a href='papers/WangXLV_CVPR17.bib'>BibTex</a> ][ <a href='https://github.com/wanglimin/UntrimmedNet'>Code</a> ] <br />
<alert>An end-to-end architecture to learn from untrimmed videos.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="SongWVH_CVPR17"><img class="paper" src="papers/SongWVH_CVPR17.png" title="Thin-Slicing Network: A Deep Structured Model for Pose Estimation in Videos" />
<div> <strong>Thin-Slicing Network: A Deep Structured Model for Pose Estimation in Videos</strong><br />
J. Song, L. Wang, L. Van Gool, and O. Hilliges  <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2017. <br />
[ <a href='https://arxiv.org/abs/1703.10898'>Paper</a> ] [ <a href='papers/SongWVH_CVPR17.bib'>BibTex</a> ][ <a href='https://ait.ethz.ch/projects/2017/thin-slicing-network/'>Project Page</a> ] <br />
<alert>End-to-end learning of FCNs and spatio-temporal relational models.</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="WangGHXQ16"><img class="paper" src="papers/WangGHXQ_TIP17.png" title="Knowledge Guided Disambiguation for Large-Scale Scene Classification with Multi-Resolution CNNs" />
<div> <strong> Knowledge Guided Disambiguation for Large-Scale Scene Classification with Multi-Resolution CNNs</strong><br />
L. Wang, S. Guo, W. Huang, Y. Xiong, and Y. Qiao  <br />
in IEEE Transactions on Image Processing (<strong>TIP</strong>), 2017. <br />
[ <a href='https://arxiv.org/abs/1610.01119'>arXiv</a> ] [ <a href='papers/WangGHXQ_TIP17.bib'>BibTex</a> ] [ <a href='https://github.com/wanglimin/MRCNN-Scene-Recognition'>Code</a> ] <br />
<alert>Solution to Places2 and LSUN challenge.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangWWZQ16"><img class="paper" src="papers/WangWWZQ_TIP17.png" title="Weakly Supervised PatchNets: Describing and Aggregating Local Patches for Scene Recognition" />
<div> <strong>Weakly Supervised PatchNets: Describing and Aggregating Local Patches for Scene Recognition</strong><br />
Z. Wang, L. Wang, Y. Wang, B. Zhang, and Y. Qiao  <br />
in IEEE Transactions on Image Processing, 2017. <br />
[ <a href='https://arxiv.org/abs/1609.00153'>arXiv</a> ] [ <a href='papers/WangWWZQ_TIP17.bib'>BibTex</a> ] [ <a href='https://github.com/wangzheallen/vsad'>Code</a> ] <br />
<alert>A hybrid representation combing deep networks and Fisher vector.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangSWHV_BMVC16"><img class="paper" src="papers/WangSWVH_BMVC16.png" title="Two-Stream SR-CNNs for Action Recognition in Videos" />
<div> <strong> Two-Stream SR-CNNs for Action Recognition in Videos</strong><br />
Y. Wang, J. Song, L. Wang, O. Hilliges, and L. Van Gool  <br />
in British Machine Vision Conference (<strong>BMVC</strong>), 2016. <br />
[ <a href='papers/WangSWVH_BMVC16.pdf'>Paper</a> ]  [ <a href='papers/WangSWVH_BMVC16.bib'>BibTex</a> ] [ <a href='https://github.com/yifita/action.sr_cnn'>Code</a> ] <br />
<alert>Explicitly incorporating human and object cues for action recognition</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="WangXWQLTV_ECCV16"><img class="paper" src="papers/WangXWQLTV_ECCV16.png" title="Temporal Segment Networks: Towards Good Practices for Deep Action Recognition" />
<div> <strong>Temporal Segment Networks: Towards Good Practices for Deep Action Recognition</strong><br />
L. Wang, Y. Xiong, Z. Wang, Y. Qiao, D. Lin, X. Tang, and L. Van Gool  <br />
in European Conference on Computer Vision (<strong>ECCV</strong>), 2016. <br />
[ <a href='papers/WangXWQLTV_ECCV16.pdf'>Paper</a> ]  [ <a href='papers/WangXWQLTV_ECCV16.bib'>BibTex</a> ] [ <a href='papers/WangXWQLTV_ECCV16_Poster.pdf'>Poster</a> ] [ <a href='https://github.com/yjxiong/temporal-segment-networks'>Code</a> ] [ <a href='https://ieeexplore.ieee.org/document/8454294'>Journal Version</a>]<br />
<alert>Proposing a segmental architecture and obtaining the state-of-the-art performance on UCF101 and HMDB51</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="XiongW_Anet16"><img class="paper" src="contests/XiongW_Anet16_r.png" title="CUHK & ETHZ & SIAT Submission to ActivityNet Challenge 2016" />
<div> <strong>CUHK & ETHZ & SIAT Submission to ActivityNet Challenge 2016</strong><br />
Y. Xiong, L. Wang, Z. Wang, B. Zhang, H. Song, W. Li, D. Lin, Y. Qiao, L. Van Gool, and X. Tang <br />
ActivityNet Large Scale Activity Recognition Challenge, in conjuction with <strong>CVPR</strong>, 2016. <br />
[ <a href='contests/XiongW_Anet16.pdf'>Paper</a> ]  [ <a>BibTex</a> ] [ <a>Presentation</a> ] [ <a href='https://github.com/yjxiong/anet2016-cuhk'>Code</a> ]<br />
<alert>Winner of ActivityNet challenge for untrimmed video classification</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangQTV_CVPR16"><img class="paper" src="papers/WangQTV_CVPR16.jpg" title="Actionness Estimation Using Hybrid Fully Convolutional Networks" />
<div> <strong>Actionness Estimation Using Hybrid Fully Convolutional Networks</strong><br />
L. Wang, Y. Qiao, X. Tang, and L. Van Gool <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2016. <br />
[ <a href='papers/WangQTV_CVPR16.pdf'>Paper</a> ]  [ <a href='papers/WangQTV_CVPR16.bib'>BibTex</a> ] [ <a href='papers/WangQTV_CVPR16_Poster.pdf'>Poster</a> ] [ <a href = 'actionness_hfcn/index.html'>Project Page</a> ] [ <a href='https://github.com/wanglimin/actionness-estimation/'>Code</a> ]<br />
<alert>Estimating actionness maps and generating action proposals</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="ZhangWWQW_CVPR16"><img class="paper" src="papers/ZhangWWQW_CVPR16.jpg" title="Real-time Action Recognition with Enhanced Motion Vector CNNs" />
<div> <strong>Real-time Action Recognition with Enhanced Motion Vector CNNs</strong><br />
B. Zhang, L. Wang, Z. Wang, Y. Qiao, and H. Wang <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2016. <br />
[ <a href='papers/ZhangWWQW_CVPR16.pdf'>Paper</a> ]  [ <a href='papers/ZhangWWQW_CVPR16.bib'>BibTex</a> ] [ <a href='papers/ZhangWWQW_CVPR16_Poster.pdf'>Poster</a> ] [ <a href = 'http://zbwglory.github.io/MV-CNN/index.html'>Project Page</a> ] [ <a href="https://github.com/zbwglory/MV-release">Code</a> ]<br />
<alert>Proposing a real-time action recognition system with two-stream CNNs.</alert>
</div>
<div class="spanner"></div>
</div>


<div class="paper" id="WangQT_CVPR15"><img class="paper" src="papers/WangQT_CVPR15.jpg" title="Action Recognition with Trajectory-Pooled Deep-Convolutional Descriptors" />
<div> <strong>Action Recognition with Trajectory-Pooled Deep-Convolutional Descriptors</strong><br />
L. Wang, Y. Qiao, and X. Tang <br />
in IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2015. <br />
[ <a href='papers/WangQT_CVPR15.pdf'>Paper</a> ]  [ <a href='papers/WangQT_CVPR15.bib'>BibTex</a> ] [ <a href='papers/WangQT_CVPR15_abstract.pdf'>Extended Abstract</a> ] [ <a href='papers/WangQT_CVPR15_Poster.pdf'>Poster<a> ] [ <a href = 'tdd/index.html'>Project Page</a> ] [ <a href = 'https://github.com/wanglimin/TDD'>Code</a> ] <br />
<alert>State-of-the-art performance: HMDB51: 65.9%, UCF101: 91.5%.</alert>
</div>
<div class="spanner"></div>
</div>
<!--
<div class="paper" id="WangWGQ_LAP15"><img class="paper" src="papers/WangWGQ_ChaLearnLAP15.jpg" title="Better Exploiting OS-CNNs for Better Event Recognition in Images" />
<div> <strong>Better Exploiting OS-CNNs for Better Event Recognition in Images</strong><br />
L. Wang, Z. Wang, S. Guo, and Y. Qiao <br />
ChaLearn Looking at People (<strong>LAP</strong>) workshop, <strong>ICCV</strong>, 2015. <br />
[ <a href='papers/WangWGQ_ChaLearnLAP15.pdf'>Paper</a>  ]  [ <a href='papers/WangWGQ_ChaLearnLAP15.bib'>BibTex</a> ] [ <a href='papers/WangWGQ_ChaLearnLAP15_slide.pdf'>Presentation</a> ] [ <a href = 'cultural_event/index.html'>Project Page</a> ] <br /> 
<alert>Obtain 84.7% mAP and secure the 3rd place.</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangWDQ_LAP15"><img class="paper" src="papers/WangWDQ_ChaLearnLAP15.jpg" title="Event Recognition Using Object-Scene Convolutional Neural Networks" />
<div> <strong>Object-Scene Convolutional Neural Networks for Event Recognition in Images</strong><br />
L. Wang, Z. Wang, W. Du, and Y. Qiao <br />
ChaLearn Looking at People (<strong>LAP</strong>) workshop, <strong>CVPR</strong>, 2015. <br />
[ <a href='papers/WangWDQ_ChaLearnLAP15.pdf'>Paper</a>  ]  [ <a href='papers/WangWDQ_ChaLearnLAP15.bib'>BibTex</a> ] [ <a href='papers/WangWDQ_ChaLearnLAP15_slide.pdf'>Presentation</a> ] [ <a href = 'cultural_event/index.html'>Project Page</a> ] <br /> 
<alert>Obtain 85.5% mAP and rank 1st on the track of cultural event recognition.</alert>
</div>
<div class="spanner"></div>
</div>
>

<!--
<div class="paper" id="WangGHQ15"><img class="paper" src="papers/WangGHQ15.jpg" title="Places205-VGGNet Models for Scene Recognition" />
<div> <strong>Places205-VGGNet Models for Scene Recognition</strong><br />
L. Wang, S. Guo, W. Huang, and Y. Qiao <br />
ArXiv 1508.01667, 2015. <br />
[ <a href='papers/WangGHQ15.pdf'>Paper</a>  ]  [ <a href='papers/WangGHQ15.bib'>BibTex</a> ] [ <a href='https://github.com/wanglimin/Places205-VGGNet.git'>Project Page</a> ] <br />
<alert>Obtain the state-of-the-art performance on the datasets of Places205, SUN397, and MIT67</alert>
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangXWQ15"><img class="paper" src="papers/WangXWQ15.jpg" title="Towards Good Practices for Very Deep Two-Stream ConvNets" />
<div> <strong>Towards Good Practices for Very Deep Two-Stream ConvNets</strong><br />
L. Wang, Y. Xiong, Z. Wang, and Y. Qiao <br />
ArXiv 1507.02159, 2015. <br />
[ <a href='papers/WangXWQ15.pdf'>Paper</a>  ]  [ <a href='papers/WangXWQ15.bib'>BibTex</a> ] [ <a href='https://github.com/yjxiong/caffe/tree/action_recog'>Code</a> ] <br /> 
<alert>Obtain 91.4% accuracy on the UCF101 dataset. Caffe extension for Multi-GPU training released.</alert>
</div>
<div class="spanner"></div>
</div>
>

<!--
<div class="paper" id="WangQT_ECCV14"><img class="paper" src="papers/WangQT_ECCV14.jpg" title="Video Action Detection with Relational Dynamic-Poselets" />
<div> <strong>Video Action Detection with Relational Dynamic-Poselets</strong><br />
L. Wang, Y. Qiao, and X. Tang <br />
European Conference on Computer Vision (<strong>ECCV</strong>), 2014. <br />
[ <a href='papers/WangQT_ECCV14.pdf'>Paper</a> ]  [ <a href='papers/WangQT_ECCV14.bib'>BibTex</a> ] [ <a href='papers/WangQT_ECCV14_Poster.pdf'>Poster</a> ] [ <a href='papers/WangQT_ECCV14_Spotlight.wmv'>Spotlight</a> ] [ <a href='release_plot.rar'>Code</a> ] <br />
<alert>Joint action recognition, action detection, and pose estimation.</alert>
</div>
<div class="spanner"></div>
</div>
-->

<!--
<div class="paper" id="WangQT_TIP14"><img class="paper" src="papers/WangQT_TIP14.jpg" title="Latent Hierarchical Model of Temporal Structure for Complex Activity Classification" />
<div> <strong>Latent Hierarchical Model of Temporal Structure for Complex Activity Classification</strong><br />
L. Wang, Y. Qiao, and X. Tang <br />
IEEE Transactions on Image Processing (<strong>TIP</strong>), Vol. 23, No. 2, 2014. <br />
[ <a href='papers/WangQT_TIP14.pdf'>Paper</a> ]  [ <a href='papers/WangQT_TIP14.bib'>BibTex</a> ]
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangQT_ICCV13"><img class="paper" src="papers/WangQT_ICCV13.jpg" title="Mining Motion Atoms and Phrases for Complex Action Recognition" />
<div> <strong>Mining Motion Atoms and Phrases for Complex Action Recognition</strong><br />
L. Wang, Y. Qiao, and X. Tang <br />
IEEE International Conference on Computer Vision (<strong>ICCV</strong>), 2013. <br />
[ <a href='papers/WangQT_ICCV13.pdf'>Paper</a> ]  [ <a href='papers/WangQT_ICCV13.bib'>BibTex</a> ] [ <a href='papers/WangQT_ICCV13_Poster.pdf'>Poster</a> ] [ <a href='papers/WangQT_ICCV13_Spotlight.ppt'>Spotlight</a> ] [ <a href = 'mofap/index.html'>Project Page</a> ]
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangQT_CVPR13"><img class="paper" src="papers/WangQT_CVPR13.jpg" title="Motionlets: Mid-Level 3D Parts for Human Motion Recognition" />
<div> <strong>Motionlets: Mid-Level 3D Parts for Human Motion Recognition</strong><br />
L. Wang, Y. Qiao, and X. Tang <br />
IEEE Conference on Computer Vision and Pattern Recognition (<strong>CVPR</strong>), 2013. <br />
[ <a href='papers/WangQT_CVPR13.pdf'>Paper</a> ]  [ <a href='papers/WangQT_CVPR13.bib'>BibTex</a> ] [ <a href='papers/WangQT_CVPR13_Poster.pdf'>Poster</a> ] [ <a href='papers/WangQT_CVPR13_Spotlight.ppt'>Spotlight</a> ] [ <a href = 'motionlet/index.html'>Project Page</a> ]
</div>
<div class="spanner"></div>
</div>

<div class="paper" id="WangWLC_MM11"><img class="paper" src="papers/WangWLC_MM11.jpg" title="Multiclass Object Detection by Combining Local Appearances and Context" />
<div> <strong>Multiclass Object Detection by Combining Local Appearances and Context</strong><br />
L. Wang, Y. Wu, T. Lu, and K. Chen<br />
in ACM International Conference on Multimedia (<strong>ACM MM</strong>), 2011. <br />
[ <a href='papers/WangWLC_MM11.pdf'>Paper</a> ] [ <a href='papers/WangWLC_MM11.bib'>BibTex</a> ]
</div>
<div class="spanner"></div>
</div>

-->
</div>
</div>

<div style="clear: both;">
<div class="section">
<h2 id="confpapers">Contests</h2>
<div class="paper">
<ul>
<li><alert>ActivityNet Large Scale Activity Recognition Challenge, 2016</alert>: Untrimmed Video Classification, <strong>Rank</strong>: 1/24. </li>
<li><alert>ImageNet Large Scale Visual Recognition Challenge, 2015</alert>: Scene Recognition, <strong>Rank</strong>: 2/25. </li>
<li><strong>ChaLearn Looking at People Challenge, 2015</strong>, <strong>Rank</strong>: 1/6</li>
<li><strong>THUMOS Action Recognition Challenge, 2015</strong>, <strong>Rank</strong>: 5/11.</li>
<li><strong>ChaLearn Looking at People Challenge, 2014</strong> , <strong>Rank</strong>: 1/6, 4/17.</li>
<li><strong>THUMOS Action Recognition Challenge, 2014</strong>,  <strong>Rank</strong>: 4/14, 2/3.</li>
<li><strong>ChaLearn Multi-Modal Gesture Recognition Challenge, 2013 </strong>,  <strong>Rank</strong>: 4/54.</li>
<li><strong>THUMOS Action Recognition Challenge, 2013</strong>, <strong>Rank</strong>: 4/16.</li>
</ul>
<div class="spanner"></div>
</div>
</div>
</div>

<div style="clear: both;">
<div class="section">
<h2 id="confpapers">Academic Service</h2>
<div class="paper">
<strong>Journal Reviewer</strong> <br>
<p> IEEE Transactions on Pattern Analysis and Machine Intelligence </p>
<p> IEEE Transactions on Image Processing </p>
<p> IEEE Transactions on Multimedia </p>
<p> IEEE Transactions on Circuits and Systems for Video Technology </p>
<p> Pattern Recognition </p>
<p> Pattern Recognition Letter </p>
<p> Image and Vision Computing </p>
<p> Computer Vision and Image Understanding </p>
<br />
<strong>Conference Reviewer</strong> <br>
<p> IEEE Conference on Computer Vision and Pattern Recognition, 2017 </p>
<p> IEEE International Conference on Automatic Face and Gesture Recognition, 2017 </p>
<p> European Conference on Computer Vision, 2016 </p>
<p> Asian Conference on Computer Vision, 2016 </p>
<p> International Conference on Pattern Recognition, 2016 </p>
<div class="spanner"></div>
</div>
</div>
</div>

<!--
<div style="clear: both;">
<div class="section"><h2>Courses</h2>
<div class="paper">
<strong>Teaching Assistant for</strong> <br>
<p> ENGG2430, Probability and Statistics for Engineers ( Spring 2015 ). </p>
<p> ENGG1100, Introduction to Engineering Design ( Autumn 2014 ). </p>
<br />
<strong>Graduate Courses</strong> <br>
<p> SEEM 5121, Numerical Optimization ( Spring 2015 ) [ <a href='http://www1.se.cuhk.edu.hk/~sqma/SEEM5121'>Webpage</a> ]. </p>
<p> IERG 6130, Advanced Topics on Machine Learning and Probabilistic Inference ( Spring 2015 ) [ <a href='http://lindahua.github.io/MLPI/'>Webpage</a> ]. </p>
<p> ELEG 5481, Signal Processing Optimization Techniques ( Spring 2013 ) [ <a href='http://dsp.ee.cuhk.edu.hk/eleg5481/'>Webpage</a> ]. </p>
<p> IERG 6210, Advanced Topic in Information Processing (Spring 2012 ) [ <a href='https://course.ie.cuhk.edu.hk/~ierg6210/'>Webpage</a> ]. </p>
<p> CSCI 5160, Spectral Algorithm ( Spring 2012) [ <a href='http://www.cse.cuhk.edu.hk/~chi/csc5160/'>Webpage</a> ]. </p>
<p> SEEM 5520, Optimization I ( Autumn 2011 ) [ <a href='http://www1.se.cuhk.edu.hk/~manchoso/1112/seem5520/'>Webpage</a> ]. </p>
<p> IERG 5154, Information Theory ( Autumn 2011 ) [ <a href="http://ieg5154.pbworks.com/w/page/8690729/FrontPage">Webpage</a> ]. </p>
</div>
</div>
</div>
-->

<div style="clear: both;">
<div class="section"><h2>Friends</h2>
<div class="paper">
<a href='http://www.vision.ee.ethz.ch/~liwenw/'>Wen Li</a> (ETH), <a href='https://ait.ethz.ch/people/song/'>Jie Song</a> (ETH), <a href='http://guoshengcv.github.io/'>Sheng Guo</a> (Malong), <a href='http://www.whuang.org/'>Weilin Huang</a> (Malong), <a href='http://zbwglory.github.io/'>Bowen Zhang</a> (USC), <a href='http://wangzheallen.github.io/'>Zhe Wang</a> (UCI), <a href='http://liwei.ml/'>Wei Li</a> (Google), <a href='http://personal.ie.cuhk.edu.hk/~xy012/'>Yuanjun Xiong</a> (Amazon), <a href='http://pengxj.github.io/'>Xiaojiang Peng</a> (SIAT), <a href='https://zhuoweic.github.io/'>Zhuowei Cai</a> (Google), <a href='https://scholar.google.com.sg/citations?user=fPwq28oAAAAJ&hl=en'>Xingxing Wang</a> (NTU)
</div>
</div>
</div>

<div style="clear:both;">
<p align="right"><font size="5">Last Updated on 24th July, 2021</a></font></p>
<p align="right"><font size="5">Published with <a href='https://pages.github.com/'>GitHub Pages</a></font></p>
</div>
</body>
</html>
