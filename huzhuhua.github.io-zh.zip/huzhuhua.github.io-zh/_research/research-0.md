---
title: "针对近海船舶小目标和模糊目标的精准识别，以及船舶异常行为的精准检测方面做出了一系列成果"
collection: research   # 本来是演讲的页面，现在改成系统性工作页面=== research
type: "research"
permalink: /research/research-0
excerpt: "A series of achievements have been made in the accurate recognition of offshore small targets and fuzzy targets, as well as the accurate detection of ship abnormal behavior."
# venue: "Testing Institute of America 2014 Annual Conference"  # 指定会议的地点
# date: 2015-01-01
# location: "Los Angeles, CA"
---
<div id="top"></div>

<a href="#top" class="up-to-top">Back to Top</a>

针对近海船舶小目标和模糊目标的精准识别，以及船舶异常行为的精准检测方面做出了一系列成果。

A series of achievements have been made in the accurate recognition of offshore small targets and fuzzy targets, as well as the accurate detection of ship abnormal behavior.
