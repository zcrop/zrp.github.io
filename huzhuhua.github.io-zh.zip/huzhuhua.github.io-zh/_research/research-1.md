---
title: "基于视觉和多传感器技术的室内机器人研究"
collection: research   
type: "research"
permalink: /research/research-1
excerpt: "Research on indoor robots based on vision and multi-sensor technology.
"
# venue: "Testing Institute of America 2014 Annual Conference"  # 指定会议的地点
# date: 2015-01-01
# location: "Los Angeles, CA"
---
<div id="top"></div>

<a href="#top" class="up-to-top">Back to Top</a>

<p>在基于计算机视觉的室内机器人的精准测控上做出了一系列成果。</p>
Research on indoor robots based on vision and multi-sensor technology.

